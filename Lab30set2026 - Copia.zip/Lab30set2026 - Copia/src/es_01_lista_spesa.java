import java.util.ArrayList;
import java.util.Arrays;

public static void main(String[] args) {
    ArrayList<String> li_spesa = new ArrayList<>();
    boolean continua = true;
    while (continua == true) {

        String scelta_s = IO.readln("inserire una scelta \n 1)AGGIUNGI PRODOTTO \n 2) VISUALIZZARE PRODOTTI \n 3) ELIMINARE PRODOTTO \n 4) VERIFICARE SE PRODOTTO PRESENTE \n 5) VISUALIZZA NUMERO PRODOTTI \n 0=USCITA");
        IO.println("\n \n \n ");
        int scelta = Integer.parseInt(scelta_s);


        if (scelta == 1) {
            String prodotto = IO.readln("INSERIRE UN PRODOTTO (non già presente)");
            prodotto = prodotto.toUpperCase(Locale.ROOT);
            prodotto=prodotto.trim();
            if (li_spesa.contains(prodotto) == false) {
                li_spesa.add(prodotto);
                IO.println(prodotto + "---AGGIUNTO ALLA LISTA");
            }//if già presente
            else {
                IO.println("---PRODOTTO GIA INSERITO");
            }
        }// SCELTA 1 FINE

        if (scelta == 2) {
            IO.println(li_spesa);
        }//fine IF 2

        if (scelta == 3) {
            String prodotto = IO.readln("INSERIRE UN PRODOTTO DA ELIMINARE");
            prodotto = prodotto.toUpperCase(Locale.ROOT);
            prodotto=prodotto.trim();
            li_spesa.remove(prodotto);
        }//fine IF 3

        if (scelta==4){
            String prodotto = IO.readln("INSERIRE UN PRODOTTO per verificare l'esistenza");
            prodotto = prodotto.toUpperCase(Locale.ROOT);
            prodotto=prodotto.trim();
            if (li_spesa.contains(prodotto)==true){
                IO.println("---PRODOTTO già PRESENTE");}
            else {IO.println("---PRODOTTO NON INSERITO");}
        } //FINE IF SCELTA 4

        if (scelta==5){
            int n_elementi =li_spesa.size();
            IO.println("---il numero di prodotti della lista è: "+ n_elementi);
        }//FINE IF 5

        if(scelta==0){continua=false;}

        if (scelta <=-1 || scelta>=6){IO.println("!!!inserire una scelta valida!!!");}

    }//FINE WHILE


}
















