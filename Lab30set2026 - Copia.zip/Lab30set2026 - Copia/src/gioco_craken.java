public static void main(String[] args) {
    //crea un percorso da sx  a dx  in cui bisogna:
    //andare da punto A a punto b evitanto le seguenti sventure
    //mine visibili   Kraken non visibile 5% prop
    //

char [][] mappa = new char[10][10];
        mappa.


}