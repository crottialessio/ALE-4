import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

public static void main(String[] args) {

    Random random = new Random();
    int n_righe = 5;
    int n_colonne = 6;


    int[][] griglia = new int[n_righe][n_colonne];
    int conta = 0;


    while (conta <12) {
        // uso per scegliere 1 n cas  n max
        int n_cas_riga = random.nextInt(n_righe);
        int n_cas_colonna = random.nextInt(n_colonne);

        if (griglia[n_cas_riga][n_cas_colonna] == 0) {
            int n_casuale = random.nextInt(99);
            griglia[n_cas_riga][n_cas_colonna] = n_casuale;
            //IO.println(griglia[n_cas_riga][n_cas_colonna]);
            conta += 1;

        }//FINE CELLA OCCUPATA
    }//FINE WHILE DI 12 CASUALI

    //UTILE PER SCRIVERE LA GRIGLIA
    for (int r = 0; r < n_righe; r++) {
        for (int c = 0; c < n_colonne; c++) {
            IO.print(griglia[r][c] + " "); //stampa il numero dell'incrocio

        }//FOR c fine
        IO.println(""); // tra 1 riga e latra sotto fa lo spazio

    }//FOR r fine


    //PARTE UTENTEEEEEE
    boolean continua = true;
    while (continua == true) {
        String ut_riga = IO.readln("INSERIRE LA RIGA DELLA CELLA SELEZIONATA");
        String ut_colonna = IO.readln("INSERIRE LA COLONNA DELLA CELLA SELEZIONATA");
        int riga_scelta = Integer.parseInt(ut_riga);
        int colonna_scelta = Integer.parseInt(ut_colonna);

        if (griglia[riga_scelta][colonna_scelta] == 0) {
            String n_cella=IO.readln("inserire il numero da assegnare alla cella");
            int cella= Integer.parseInt(n_cella);
            griglia[riga_scelta][colonna_scelta]=cella;
            IO.println("GRIGLIA OTTENUTA");
            continua = false;
        } else {
            IO.println("LA CELLA è OCCUPATA sceglierne un'altra");
            IO.print(" ");
        }
    }

    for (int r = 0; r < n_righe; r++) {
        for (int c = 0; c < n_colonne; c++) {
            IO.print(griglia[r][c] + " "); //stampa il numero dell'incrocio

        }//FOR c fine
        IO.println(""); // tra 1 riga e latra sotto fa lo spazio

    }//FOR r fine
}
















